var searchData=
[
  ['charactergroundingreport',['CharacterGroundingReport',['../struct_kinematic_character_controller_1_1_character_grounding_report.html',1,'KinematicCharacterController']]],
  ['charactertransientgroundingreport',['CharacterTransientGroundingReport',['../struct_kinematic_character_controller_1_1_character_transient_grounding_report.html',1,'KinematicCharacterController']]]
];
