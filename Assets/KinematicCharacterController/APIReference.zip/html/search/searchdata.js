var indexSectionsWithContent =
{
  0: "abcdefghiklmoprstuv",
  1: "bchkopr",
  2: "k",
  3: "abcefghimoprsuv",
  4: "abcdghilmprs",
  5: "acimotv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Properties"
};

